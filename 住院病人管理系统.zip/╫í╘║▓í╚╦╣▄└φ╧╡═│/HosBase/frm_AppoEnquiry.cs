﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HosBase
{
    public partial class frm_AppoEnquiry : Form
    {
        private DataTable PatientTable;

        public frm_AppoEnquiry()
        {
            InitializeComponent();
        }

        private void btn_Load1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString = "Server=(local);Database=HosBase;Integrated Security=sspi";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sqlConnection;
            
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            sqlDataAdapter.SelectCommand = sqlCommand;
            
            DataTable patientTable = new DataTable();
            sqlConnection.Open();
            
            sqlCommand.CommandText = "SELECT*FROM tb_Patient;";
            sqlDataAdapter.Fill(patientTable);
            sqlConnection.Close();
            this.PatientTable = patientTable;
            this.dgv_AppoEnquiry.Columns.Clear();
            this.dgv_AppoEnquiry.DataSource = patientTable;
            this.dgv_AppoEnquiry.Columns["No"].ReadOnly = true;
            this.dgv_AppoEnquiry.Columns["No"].HeaderText = "住院病历号";
            this.dgv_AppoEnquiry.Columns["ID"].HeaderText = "身份证号";
            this.dgv_AppoEnquiry.Columns["ExpenseNo"].HeaderText = "费别";
            this.dgv_AppoEnquiry.Columns["AdmissionDate"].HeaderText = "入院日期";
            this.dgv_AppoEnquiry.Columns["Name"].HeaderText = "姓名";
            this.dgv_AppoEnquiry.Columns["Gender"].HeaderText = "性别";
            this.dgv_AppoEnquiry.Columns["Hospitalization"].HeaderText = "住院次数";
            
            this.dgv_AppoEnquiry.Columns["ReservationNo"].HeaderText = "预约号";
            this.dgv_AppoEnquiry.Columns["OutpatientNo"].HeaderText = "门诊号";
            this.dgv_AppoEnquiry.Columns["MeCertificateNo"].HeaderText = "医疗证号";
            this.dgv_AppoEnquiry.Columns["Nation"].HeaderText = "民族";
            this.dgv_AppoEnquiry.Columns["Marital"].HeaderText = "婚姻状况";
            this.dgv_AppoEnquiry.Columns["Address"].HeaderText = "地址";
            this.dgv_AppoEnquiry.Columns["Diagnosis"].HeaderText = "入院诊断（文本）";
            this.dgv_AppoEnquiry.Columns["DepartmentNo"].Visible = false;
            

            this.dgv_AppoEnquiry.Columns[this.dgv_AppoEnquiry.Columns.Count - 2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=HosBase;Integrated Security=sspi";
            SqlCommand insertCommand = new SqlCommand();
            insertCommand.Connection = sqlConnection;
            insertCommand.CommandText =
                "INSERT tb_Patient" +
                 "(No,ID,ExpenseNo,AdmissionDate,Name,Gender,Hospitalization,DepartmentNo,ReservationNo,OutpatientNo,MeCertificateNo,Nation,Marital,Address,Diagnosis)" +
                 " VALUES(@No,@ID,@ExpenseNo,@AdmissionDate,@Name,@Gender,@Hospitalization,@DepartmentNo,@ReservationNo,@OutpatientNo,@MeCertificateNo,@Nation,@Marital,@Address,@Diagnosis);";
            insertCommand.Parameters.Add("@No", SqlDbType.Char, 5, "No");
            insertCommand.Parameters.Add("@ID", SqlDbType.Char, 18, "ID");
            insertCommand.Parameters.Add("@ExpenseNo", SqlDbType.VarChar, 0, "ExpenseNo");
            insertCommand.Parameters.Add("@AdmissionDate", SqlDbType.VarChar, 0, "AdmissionDate");
            insertCommand.Parameters.Add("@Name", SqlDbType.VarChar, 0, "Name");
            insertCommand.Parameters.Add("@Gender", SqlDbType.VarChar, 0, "Gender");
            insertCommand.Parameters.Add("@Hospitalization", SqlDbType.VarChar, 0, "Hospitalization");
            insertCommand.Parameters.Add("@DepartmentNo", SqlDbType.VarChar, 0, "DepartmentNo");
            insertCommand.Parameters.Add("@ReservationNo", SqlDbType.VarChar, 0, "ReservationNo");
            insertCommand.Parameters.Add("@OutpatientNo", SqlDbType.VarChar, 0, "OutpatientNo");
            insertCommand.Parameters.Add("@MeCertificateNo", SqlDbType.VarChar, 0, "MeCertificateNo");
            insertCommand.Parameters.Add("@Nation", SqlDbType.VarChar, 0, "Nation");
            insertCommand.Parameters.Add("@Marital", SqlDbType.Char, 2, "Marital");
            insertCommand.Parameters.Add("@Address", SqlDbType.VarChar, 0, "Address");
            insertCommand.Parameters.Add("@Diagnosis", SqlDbType.VarChar, 0, "Diagnosis");
            SqlCommand updateCommand = new SqlCommand();
            updateCommand.Connection = sqlConnection;
            updateCommand.CommandText =
                "UPDATE tb_Patient" +
                 " SET No=@NewNo,ExpenseNo=@ExpenseNo,AdmissionNo=@AdmissionNo,Name=@Name,Gender=@Gender,Hospitalization=@Hospitalization,DepartmentNo=@DepartmentNo,ReservationNo=@ReservationNo,OutpatientNo=@OutpatientNo,MeCertificateNo=@MeCertificateNo,Nation=@Nation,Marital=@Marital,Address=@Address,Diagnosis=@Diagnosis" +
                 " WHERE No=@OldNo;";
            updateCommand.Parameters.Add("@NewNo", SqlDbType.Char,5, "No");
            updateCommand.Parameters.Add("@ID", SqlDbType.Char, 18, "ID");
            updateCommand.Parameters.Add("@ExpenseNo", SqlDbType.VarChar, 0, "ExpenseNo");
            updateCommand.Parameters.Add("@AdmissionDate", SqlDbType.VarChar, 0, "AdmissionDate");
            updateCommand.Parameters.Add("@Name", SqlDbType.VarChar, 0, "Name");
            updateCommand.Parameters.Add("@Gender", SqlDbType.VarChar, 0, "Gender");
            updateCommand.Parameters.Add("@Hospitalization", SqlDbType.VarChar, 0, "Hospitalization");
            updateCommand.Parameters.Add("@DepartmentNo", SqlDbType.VarChar, 0, "DepartmentNo");
            updateCommand.Parameters.Add("@ReservationNo", SqlDbType.VarChar, 0, "ReservationNo");
            updateCommand.Parameters.Add("@OutpatientNo", SqlDbType.VarChar, 0, "OutpatientNo");
            updateCommand.Parameters.Add("@MeCertificateNo", SqlDbType.VarChar, 0, "MeCertificateNo");
            updateCommand.Parameters.Add("@Nation", SqlDbType.VarChar, 0, "Nation");
            updateCommand.Parameters.Add("@Marital", SqlDbType.Char, 2, "Marital");
            updateCommand.Parameters.Add("@Address", SqlDbType.VarChar, 0, "Address");
            updateCommand.Parameters.Add("@Diagnosis", SqlDbType.VarChar, 0, "Diagnosis");
            updateCommand.Parameters.Add("@OldNo", SqlDbType.Char, 5, "No");
            updateCommand.Parameters["@OldNo"].SourceVersion = DataRowVersion.Original;
            SqlCommand deleteCommand = new SqlCommand();
            deleteCommand.Connection = sqlConnection;
            deleteCommand.CommandText =
                "DELETE tb_Patient WHERE No=@No;";
            deleteCommand.Parameters.Add("@No", SqlDbType.Char, 5, "No");
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            sqlDataAdapter.InsertCommand = insertCommand;
            sqlDataAdapter.UpdateCommand = updateCommand;
            sqlDataAdapter.DeleteCommand = deleteCommand;
            DataTable patientTable = (DataTable)this.dgv_AppoEnquiry.DataSource;
            sqlConnection.Open();
            int rowAffected = sqlDataAdapter.Update(patientTable);
            sqlConnection.Close();
            MessageBox.Show($"更新{rowAffected}行。");


        }
    }
}
