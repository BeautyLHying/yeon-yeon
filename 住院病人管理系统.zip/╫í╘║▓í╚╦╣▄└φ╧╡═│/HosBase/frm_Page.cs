﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HosBase
{
    public partial class frm_Page : Form
    {
        private string v;

        public frm_Page()
        {
            InitializeComponent();
            pl_Input.Visible = false;
            pl_AppoEnquiry.Visible = false;


        }
        
        public frm_Page(string v)
        {
            this.v = v;
        }

        private void lbl_Share_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Click(object sender, EventArgs e)
        {

        }

        private void sc_Algorithm1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void frm_Page_Load(object sender, EventArgs e)
        {

        }

        private void btn_Load_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString =
                "Server=(local);Database=HosBase;Integrated Security=sspi";
           
            SqlCommand sqlCommand2 = sqlConnection.CreateCommand();
            if (this.rdb_Male.Checked == true)
            {
                sqlCommand2.CommandText =
                    $"INSERT tb_Patient(No,ID,ExpenseNo,AdmissionDate,Name,Gender,Hospitalization,DepartmentNo,ReservationNo,OutpatientNo,MeCertificateNo,Nation,Marital,Address,Diagnosis)  VALUES ('{this.txb_RecordNo.Text.Trim()}'"+
                    $",'{this.txb_ID.Text.Trim()}','{this.cmb_Expense.Text.Trim()}','{this.dtp_AdmissionDate.Value}','{this.txb_Name.Text.Trim()}',1,'{this.txb_Hospitalization.Text.Trim()}'"+
            $" ,'{this.cmb_Department.Text.Trim()}','{this.txb_ReservationNo.Text.Trim()}','{this.txb_OutpatientNo.Text.Trim()}','{this.txb_MeCertificateNo.Text.Trim()}'"+
             $",'{this.txb_Nation.Text.Trim()}','{this.txb_Marital.Text.Trim()}','{this.txb_Address.Text.Trim()}','{this.txb_Marital.Text.Trim()}')";
             
               

            }
            else
            {
                sqlCommand2.CommandText =
                     $"INSERT tb_Patient(No,ID,ExpenseNo,AdmissionDate,Name,Gender,Hospitalization,DepartmentNo,ReservationNo,OutpatientNo,MeCertificateNo,Nation,Marital,Address,Diagnosis)  VALUES ('{this.txb_RecordNo.Text.Trim()}'" +
                     $",'{this.txb_ID.Text.Trim()}','{this.cmb_Expense.Text.Trim()}','{this.dtp_AdmissionDate.Value}','{this.txb_Name.Text.Trim()}',0,'{this.txb_Hospitalization.Text.Trim()}'" +
             $" ,'{this.cmb_Department.Text.Trim()}','{this.txb_ReservationNo.Text.Trim()}','{this.txb_OutpatientNo.Text.Trim()}','{this.txb_MeCertificateNo.Text.Trim()}'" +
              $",'{this.txb_Nation.Text.Trim()}','{this.txb_Marital.Text.Trim()}','{this.txb_Address.Text.Trim()}','{this.txb_Marital.Text.Trim()}')";

            }
            sqlConnection.Open();

            int rowAffected2 = sqlCommand2.ExecuteNonQuery();
            sqlConnection.Close();
            if (rowAffected2 == 1)
            {
                MessageBox.Show("保存成功！");
            }
            else
            {
                MessageBox.Show("保存失败！");
            }


        }

        private void lb_Appointment_SelectedIndexChanged(object sender, EventArgs e)
        {
            pl_Input.Visible = false;
            pl_AppoEnquiry.Visible = false;
            if (lb_Appointment.Text=="预约录入")
            {
                pl_Input.Visible = true;

            }
            if (lb_Appointment.Text=="预约查询")
            {
                pl_Input.Visible = false;
                pl_AppoEnquiry.Visible = true;
                
            }
        }

        private void btn_AppoEnquiry_Click(object sender, EventArgs e)
        {
            frm_AppoEnquiry frm_AppoEnquiry = new frm_AppoEnquiry();
            frm_AppoEnquiry.Show();
        }

        private void pl_AppoEnquiry_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pl_Input_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txb_RecordNo_TextChanged(object sender, EventArgs e)
        {

        }
    }

    internal class frm_PageClosedEventArgs
    {
    }
}
