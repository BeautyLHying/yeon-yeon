﻿namespace HosBase
{
    partial class frm_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tc_System = new System.Windows.Forms.TabControl();
            this.tp_Window = new System.Windows.Forms.TabPage();
            this.gb_Window = new System.Windows.Forms.GroupBox();
            this.pl_Input = new System.Windows.Forms.Panel();
            this.pl_AppoEnquiry = new System.Windows.Forms.Panel();
            this.btn_AppoEnquiry = new System.Windows.Forms.Button();
            this.txb_Hospitalization = new System.Windows.Forms.TextBox();
            this.txb_Diagnosis = new System.Windows.Forms.TextBox();
            this.lbl_Diagnosis = new System.Windows.Forms.Label();
            this.txb_Address = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.txb_Marital = new System.Windows.Forms.TextBox();
            this.lbl_Marital = new System.Windows.Forms.Label();
            this.txb_Nation = new System.Windows.Forms.TextBox();
            this.lbl_Nation = new System.Windows.Forms.Label();
            this.txb_MeCertificateNo = new System.Windows.Forms.TextBox();
            this.lbl_MeCertificateNo = new System.Windows.Forms.Label();
            this.txb_OutpatientNo = new System.Windows.Forms.TextBox();
            this.lbl_OutpatientNo = new System.Windows.Forms.Label();
            this.txb_ReservationNo = new System.Windows.Forms.TextBox();
            this.lbl_ReservationNo = new System.Windows.Forms.Label();
            this.btn_Load = new System.Windows.Forms.Button();
            this.cmb_Department = new System.Windows.Forms.ComboBox();
            this.lbl_Department = new System.Windows.Forms.Label();
            this.lbl_Hospitalization = new System.Windows.Forms.Label();
            this.rdb_Female = new System.Windows.Forms.RadioButton();
            this.rdb_Male = new System.Windows.Forms.RadioButton();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.txb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.dtp_AdmissionDate = new System.Windows.Forms.DateTimePicker();
            this.lbl_AdmissionDate = new System.Windows.Forms.Label();
            this.cmb_Expense = new System.Windows.Forms.ComboBox();
            this.lbl_Expense = new System.Windows.Forms.Label();
            this.txb_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.txb_RecordNo = new System.Windows.Forms.TextBox();
            this.lbl_RecordNo = new System.Windows.Forms.Label();
            this.lbl_Input = new System.Windows.Forms.Label();
            this.gb_Other = new System.Windows.Forms.GroupBox();
            this.lb_Other = new System.Windows.Forms.ListBox();
            this.gb_Dictionary = new System.Windows.Forms.GroupBox();
            this.lb_Dictionary = new System.Windows.Forms.ListBox();
            this.gb_Count = new System.Windows.Forms.GroupBox();
            this.lb_Count = new System.Windows.Forms.ListBox();
            this.gb_Comprehensive = new System.Windows.Forms.GroupBox();
            this.lb_Comprehensive = new System.Windows.Forms.ListBox();
            this.gb_Cashier = new System.Windows.Forms.GroupBox();
            this.lb_Cashier = new System.Windows.Forms.ListBox();
            this.gb_Fee = new System.Windows.Forms.GroupBox();
            this.lb_Fee = new System.Windows.Forms.ListBox();
            this.gb_Patient = new System.Windows.Forms.GroupBox();
            this.lb_Patient = new System.Windows.Forms.ListBox();
            this.gb_Appointment = new System.Windows.Forms.GroupBox();
            this.lb_Appointment = new System.Windows.Forms.ListBox();
            this.tp_System = new System.Windows.Forms.TabPage();
            this.pl_Initialization = new System.Windows.Forms.Panel();
            this.btn_Close = new System.Windows.Forms.Button();
            this.btn_Abandon = new System.Windows.Forms.Button();
            this.btn_Keep = new System.Windows.Forms.Button();
            this.gb_Sign = new System.Windows.Forms.GroupBox();
            this.btn_Share = new System.Windows.Forms.Button();
            this.btn_Sum = new System.Windows.Forms.Button();
            this.btn_Total = new System.Windows.Forms.Button();
            this.btn_Ratio = new System.Windows.Forms.Button();
            this.btn_Subsection = new System.Windows.Forms.Button();
            this.lbl_Algorithm2 = new System.Windows.Forms.Label();
            this.lbl_Algorithm1 = new System.Windows.Forms.Label();
            this.lbl_Share = new System.Windows.Forms.Label();
            this.cb_Share = new System.Windows.Forms.CheckBox();
            this.cb_Fee = new System.Windows.Forms.CheckBox();
            this.gb_Bedfee = new System.Windows.Forms.GroupBox();
            this.gb_Calculation = new System.Windows.Forms.GroupBox();
            this.rdb_End = new System.Windows.Forms.RadioButton();
            this.rdb_First = new System.Windows.Forms.RadioButton();
            this.lbl_Hint = new System.Windows.Forms.Label();
            this.txb_Bedfee = new System.Windows.Forms.TextBox();
            this.lbl_Bedfee = new System.Windows.Forms.Label();
            this.gb_Number = new System.Windows.Forms.GroupBox();
            this.gb_Switch = new System.Windows.Forms.GroupBox();
            this.rdb_Automatic = new System.Windows.Forms.RadioButton();
            this.rdb_Manual = new System.Windows.Forms.RadioButton();
            this.txb_Medical = new System.Windows.Forms.TextBox();
            this.txb_Charge = new System.Windows.Forms.TextBox();
            this.txb_Appointment = new System.Windows.Forms.TextBox();
            this.txb_Receipt = new System.Windows.Forms.TextBox();
            this.lbl_Medical = new System.Windows.Forms.Label();
            this.lbl_Charge = new System.Windows.Forms.Label();
            this.lbl_Appointment = new System.Windows.Forms.Label();
            this.lbl_Receipt = new System.Windows.Forms.Label();
            this.lb_System = new System.Windows.Forms.ListBox();
            this.gb_System = new System.Windows.Forms.GroupBox();
            this.tp_management = new System.Windows.Forms.TabPage();
            this.tc_System.SuspendLayout();
            this.tp_Window.SuspendLayout();
            this.gb_Window.SuspendLayout();
            this.pl_Input.SuspendLayout();
            this.pl_AppoEnquiry.SuspendLayout();
            this.gb_Other.SuspendLayout();
            this.gb_Dictionary.SuspendLayout();
            this.gb_Count.SuspendLayout();
            this.gb_Comprehensive.SuspendLayout();
            this.gb_Cashier.SuspendLayout();
            this.gb_Fee.SuspendLayout();
            this.gb_Patient.SuspendLayout();
            this.gb_Appointment.SuspendLayout();
            this.tp_System.SuspendLayout();
            this.pl_Initialization.SuspendLayout();
            this.gb_Sign.SuspendLayout();
            this.gb_Bedfee.SuspendLayout();
            this.gb_Calculation.SuspendLayout();
            this.gb_Number.SuspendLayout();
            this.gb_Switch.SuspendLayout();
            this.SuspendLayout();
            // 
            // tc_System
            // 
            this.tc_System.Controls.Add(this.tp_Window);
            this.tc_System.Controls.Add(this.tp_System);
            this.tc_System.Controls.Add(this.tp_management);
            this.tc_System.Location = new System.Drawing.Point(12, 27);
            this.tc_System.Name = "tc_System";
            this.tc_System.SelectedIndex = 0;
            this.tc_System.Size = new System.Drawing.Size(896, 542);
            this.tc_System.TabIndex = 0;
            // 
            // tp_Window
            // 
            this.tp_Window.Controls.Add(this.gb_Window);
            this.tp_Window.Location = new System.Drawing.Point(4, 25);
            this.tp_Window.Name = "tp_Window";
            this.tp_Window.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Window.Size = new System.Drawing.Size(888, 513);
            this.tp_Window.TabIndex = 1;
            this.tp_Window.Text = "窗口设计";
            this.tp_Window.UseVisualStyleBackColor = true;
            // 
            // gb_Window
            // 
            this.gb_Window.Controls.Add(this.pl_AppoEnquiry);
            this.gb_Window.Controls.Add(this.pl_Input);
            this.gb_Window.Controls.Add(this.gb_Other);
            this.gb_Window.Controls.Add(this.gb_Dictionary);
            this.gb_Window.Controls.Add(this.gb_Count);
            this.gb_Window.Controls.Add(this.gb_Comprehensive);
            this.gb_Window.Controls.Add(this.gb_Cashier);
            this.gb_Window.Controls.Add(this.gb_Fee);
            this.gb_Window.Controls.Add(this.gb_Patient);
            this.gb_Window.Controls.Add(this.gb_Appointment);
            this.gb_Window.Location = new System.Drawing.Point(6, 6);
            this.gb_Window.Name = "gb_Window";
            this.gb_Window.Size = new System.Drawing.Size(848, 501);
            this.gb_Window.TabIndex = 0;
            this.gb_Window.TabStop = false;
            this.gb_Window.Text = "窗口设计";
            // 
            // pl_Input
            // 
            this.pl_Input.BackColor = System.Drawing.Color.Linen;
            this.pl_Input.Controls.Add(this.txb_Hospitalization);
            this.pl_Input.Controls.Add(this.txb_Diagnosis);
            this.pl_Input.Controls.Add(this.lbl_Diagnosis);
            this.pl_Input.Controls.Add(this.txb_Address);
            this.pl_Input.Controls.Add(this.lbl_Address);
            this.pl_Input.Controls.Add(this.txb_Marital);
            this.pl_Input.Controls.Add(this.lbl_Marital);
            this.pl_Input.Controls.Add(this.txb_Nation);
            this.pl_Input.Controls.Add(this.lbl_Nation);
            this.pl_Input.Controls.Add(this.txb_MeCertificateNo);
            this.pl_Input.Controls.Add(this.lbl_MeCertificateNo);
            this.pl_Input.Controls.Add(this.txb_OutpatientNo);
            this.pl_Input.Controls.Add(this.lbl_OutpatientNo);
            this.pl_Input.Controls.Add(this.txb_ReservationNo);
            this.pl_Input.Controls.Add(this.lbl_ReservationNo);
            this.pl_Input.Controls.Add(this.btn_Load);
            this.pl_Input.Controls.Add(this.cmb_Department);
            this.pl_Input.Controls.Add(this.lbl_Department);
            this.pl_Input.Controls.Add(this.lbl_Hospitalization);
            this.pl_Input.Controls.Add(this.rdb_Female);
            this.pl_Input.Controls.Add(this.rdb_Male);
            this.pl_Input.Controls.Add(this.lbl_Gender);
            this.pl_Input.Controls.Add(this.txb_Name);
            this.pl_Input.Controls.Add(this.lbl_Name);
            this.pl_Input.Controls.Add(this.dtp_AdmissionDate);
            this.pl_Input.Controls.Add(this.lbl_AdmissionDate);
            this.pl_Input.Controls.Add(this.cmb_Expense);
            this.pl_Input.Controls.Add(this.lbl_Expense);
            this.pl_Input.Controls.Add(this.txb_ID);
            this.pl_Input.Controls.Add(this.lbl_ID);
            this.pl_Input.Controls.Add(this.txb_RecordNo);
            this.pl_Input.Controls.Add(this.lbl_RecordNo);
            this.pl_Input.Controls.Add(this.lbl_Input);
            this.pl_Input.Location = new System.Drawing.Point(131, 24);
            this.pl_Input.Name = "pl_Input";
            this.pl_Input.Size = new System.Drawing.Size(555, 398);
            this.pl_Input.TabIndex = 9;
            this.pl_Input.Paint += new System.Windows.Forms.PaintEventHandler(this.pl_Input_Paint);
            // 
            // pl_AppoEnquiry
            // 
            this.pl_AppoEnquiry.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pl_AppoEnquiry.Controls.Add(this.btn_AppoEnquiry);
            this.pl_AppoEnquiry.Location = new System.Drawing.Point(119, 19);
            this.pl_AppoEnquiry.Name = "pl_AppoEnquiry";
            this.pl_AppoEnquiry.Size = new System.Drawing.Size(383, 268);
            this.pl_AppoEnquiry.TabIndex = 34;
            this.pl_AppoEnquiry.Paint += new System.Windows.Forms.PaintEventHandler(this.pl_AppoEnquiry_Paint);
            // 
            // btn_AppoEnquiry
            // 
            this.btn_AppoEnquiry.Location = new System.Drawing.Point(68, 45);
            this.btn_AppoEnquiry.Name = "btn_AppoEnquiry";
            this.btn_AppoEnquiry.Size = new System.Drawing.Size(75, 23);
            this.btn_AppoEnquiry.TabIndex = 0;
            this.btn_AppoEnquiry.Text = "预约查询";
            this.btn_AppoEnquiry.UseVisualStyleBackColor = true;
            this.btn_AppoEnquiry.Click += new System.EventHandler(this.btn_AppoEnquiry_Click);
            // 
            // txb_Hospitalization
            // 
            this.txb_Hospitalization.Location = new System.Drawing.Point(91, 141);
            this.txb_Hospitalization.Name = "txb_Hospitalization";
            this.txb_Hospitalization.Size = new System.Drawing.Size(100, 25);
            this.txb_Hospitalization.TabIndex = 33;
            // 
            // txb_Diagnosis
            // 
            this.txb_Diagnosis.Location = new System.Drawing.Point(159, 301);
            this.txb_Diagnosis.Name = "txb_Diagnosis";
            this.txb_Diagnosis.Size = new System.Drawing.Size(100, 25);
            this.txb_Diagnosis.TabIndex = 32;
            // 
            // lbl_Diagnosis
            // 
            this.lbl_Diagnosis.AutoSize = true;
            this.lbl_Diagnosis.Location = new System.Drawing.Point(18, 304);
            this.lbl_Diagnosis.Name = "lbl_Diagnosis";
            this.lbl_Diagnosis.Size = new System.Drawing.Size(135, 15);
            this.lbl_Diagnosis.TabIndex = 31;
            this.lbl_Diagnosis.Text = "入院诊断（文本）:";
            // 
            // txb_Address
            // 
            this.txb_Address.Location = new System.Drawing.Point(318, 256);
            this.txb_Address.Name = "txb_Address";
            this.txb_Address.Size = new System.Drawing.Size(100, 25);
            this.txb_Address.TabIndex = 30;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Location = new System.Drawing.Point(236, 266);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(75, 15);
            this.lbl_Address.TabIndex = 29;
            this.lbl_Address.Text = "家庭住址:";
            // 
            // txb_Marital
            // 
            this.txb_Marital.Location = new System.Drawing.Point(91, 257);
            this.txb_Marital.Name = "txb_Marital";
            this.txb_Marital.Size = new System.Drawing.Size(100, 25);
            this.txb_Marital.TabIndex = 28;
            // 
            // lbl_Marital
            // 
            this.lbl_Marital.AutoSize = true;
            this.lbl_Marital.Location = new System.Drawing.Point(15, 260);
            this.lbl_Marital.Name = "lbl_Marital";
            this.lbl_Marital.Size = new System.Drawing.Size(82, 15);
            this.lbl_Marital.TabIndex = 27;
            this.lbl_Marital.Text = "婚姻状况：";
            // 
            // txb_Nation
            // 
            this.txb_Nation.Location = new System.Drawing.Point(318, 216);
            this.txb_Nation.Name = "txb_Nation";
            this.txb_Nation.Size = new System.Drawing.Size(100, 25);
            this.txb_Nation.TabIndex = 26;
            // 
            // lbl_Nation
            // 
            this.lbl_Nation.AutoSize = true;
            this.lbl_Nation.Location = new System.Drawing.Point(233, 227);
            this.lbl_Nation.Name = "lbl_Nation";
            this.lbl_Nation.Size = new System.Drawing.Size(52, 15);
            this.lbl_Nation.TabIndex = 25;
            this.lbl_Nation.Text = "民族：";
            // 
            // txb_MeCertificateNo
            // 
            this.txb_MeCertificateNo.Location = new System.Drawing.Point(91, 218);
            this.txb_MeCertificateNo.Name = "txb_MeCertificateNo";
            this.txb_MeCertificateNo.Size = new System.Drawing.Size(100, 25);
            this.txb_MeCertificateNo.TabIndex = 24;
            // 
            // lbl_MeCertificateNo
            // 
            this.lbl_MeCertificateNo.AutoSize = true;
            this.lbl_MeCertificateNo.Location = new System.Drawing.Point(12, 228);
            this.lbl_MeCertificateNo.Name = "lbl_MeCertificateNo";
            this.lbl_MeCertificateNo.Size = new System.Drawing.Size(82, 15);
            this.lbl_MeCertificateNo.TabIndex = 23;
            this.lbl_MeCertificateNo.Text = "医疗证号：";
            // 
            // txb_OutpatientNo
            // 
            this.txb_OutpatientNo.Location = new System.Drawing.Point(318, 180);
            this.txb_OutpatientNo.Name = "txb_OutpatientNo";
            this.txb_OutpatientNo.Size = new System.Drawing.Size(100, 25);
            this.txb_OutpatientNo.TabIndex = 22;
            // 
            // lbl_OutpatientNo
            // 
            this.lbl_OutpatientNo.AutoSize = true;
            this.lbl_OutpatientNo.Location = new System.Drawing.Point(233, 190);
            this.lbl_OutpatientNo.Name = "lbl_OutpatientNo";
            this.lbl_OutpatientNo.Size = new System.Drawing.Size(67, 15);
            this.lbl_OutpatientNo.TabIndex = 21;
            this.lbl_OutpatientNo.Text = "门诊号：";
            // 
            // txb_ReservationNo
            // 
            this.txb_ReservationNo.Location = new System.Drawing.Point(91, 183);
            this.txb_ReservationNo.Name = "txb_ReservationNo";
            this.txb_ReservationNo.Size = new System.Drawing.Size(100, 25);
            this.txb_ReservationNo.TabIndex = 20;
            // 
            // lbl_ReservationNo
            // 
            this.lbl_ReservationNo.AutoSize = true;
            this.lbl_ReservationNo.Location = new System.Drawing.Point(12, 186);
            this.lbl_ReservationNo.Name = "lbl_ReservationNo";
            this.lbl_ReservationNo.Size = new System.Drawing.Size(67, 15);
            this.lbl_ReservationNo.TabIndex = 19;
            this.lbl_ReservationNo.Text = "预约号：";
            // 
            // btn_Load
            // 
            this.btn_Load.Location = new System.Drawing.Point(430, 351);
            this.btn_Load.Name = "btn_Load";
            this.btn_Load.Size = new System.Drawing.Size(75, 23);
            this.btn_Load.TabIndex = 18;
            this.btn_Load.Text = "保存";
            this.btn_Load.UseVisualStyleBackColor = true;
            this.btn_Load.Click += new System.EventHandler(this.btn_Load_Click);
            // 
            // cmb_Department
            // 
            this.cmb_Department.FormattingEnabled = true;
            this.cmb_Department.Items.AddRange(new object[] {
            "内一科",
            "内二科",
            "外一科",
            "外二科",
            "内三科",
            "外三科"});
            this.cmb_Department.Location = new System.Drawing.Point(318, 141);
            this.cmb_Department.Name = "cmb_Department";
            this.cmb_Department.Size = new System.Drawing.Size(121, 23);
            this.cmb_Department.TabIndex = 17;
            // 
            // lbl_Department
            // 
            this.lbl_Department.AutoSize = true;
            this.lbl_Department.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Department.Location = new System.Drawing.Point(230, 144);
            this.lbl_Department.Name = "lbl_Department";
            this.lbl_Department.Size = new System.Drawing.Size(82, 15);
            this.lbl_Department.TabIndex = 16;
            this.lbl_Department.Text = "入院科室：";
            // 
            // lbl_Hospitalization
            // 
            this.lbl_Hospitalization.AutoSize = true;
            this.lbl_Hospitalization.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Hospitalization.Location = new System.Drawing.Point(6, 141);
            this.lbl_Hospitalization.Name = "lbl_Hospitalization";
            this.lbl_Hospitalization.Size = new System.Drawing.Size(82, 15);
            this.lbl_Hospitalization.TabIndex = 14;
            this.lbl_Hospitalization.Text = "住院次数：";
            // 
            // rdb_Female
            // 
            this.rdb_Female.AutoSize = true;
            this.rdb_Female.Location = new System.Drawing.Point(328, 107);
            this.rdb_Female.Name = "rdb_Female";
            this.rdb_Female.Size = new System.Drawing.Size(43, 19);
            this.rdb_Female.TabIndex = 13;
            this.rdb_Female.TabStop = true;
            this.rdb_Female.Text = "女";
            this.rdb_Female.UseVisualStyleBackColor = true;
            // 
            // rdb_Male
            // 
            this.rdb_Male.AutoSize = true;
            this.rdb_Male.Location = new System.Drawing.Point(268, 107);
            this.rdb_Male.Name = "rdb_Male";
            this.rdb_Male.Size = new System.Drawing.Size(43, 19);
            this.rdb_Male.TabIndex = 12;
            this.rdb_Male.TabStop = true;
            this.rdb_Male.Text = "男";
            this.rdb_Male.UseVisualStyleBackColor = true;
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Gender.Location = new System.Drawing.Point(217, 107);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(52, 15);
            this.lbl_Gender.TabIndex = 11;
            this.lbl_Gender.Text = "性别：";
            // 
            // txb_Name
            // 
            this.txb_Name.Location = new System.Drawing.Point(91, 104);
            this.txb_Name.Name = "txb_Name";
            this.txb_Name.Size = new System.Drawing.Size(100, 25);
            this.txb_Name.TabIndex = 10;
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Name.Location = new System.Drawing.Point(9, 107);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(52, 15);
            this.lbl_Name.TabIndex = 9;
            this.lbl_Name.Text = "姓名：";
            // 
            // dtp_AdmissionDate
            // 
            this.dtp_AdmissionDate.Location = new System.Drawing.Point(328, 72);
            this.dtp_AdmissionDate.Name = "dtp_AdmissionDate";
            this.dtp_AdmissionDate.Size = new System.Drawing.Size(200, 25);
            this.dtp_AdmissionDate.TabIndex = 8;
            // 
            // lbl_AdmissionDate
            // 
            this.lbl_AdmissionDate.AutoSize = true;
            this.lbl_AdmissionDate.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_AdmissionDate.Location = new System.Drawing.Point(229, 79);
            this.lbl_AdmissionDate.Name = "lbl_AdmissionDate";
            this.lbl_AdmissionDate.Size = new System.Drawing.Size(82, 15);
            this.lbl_AdmissionDate.TabIndex = 7;
            this.lbl_AdmissionDate.Text = "入院日期：";
            // 
            // cmb_Expense
            // 
            this.cmb_Expense.FormattingEnabled = true;
            this.cmb_Expense.Items.AddRange(new object[] {
            "综合医疗服务类",
            "医技诊疗类",
            "临床诊疗类"});
            this.cmb_Expense.Location = new System.Drawing.Point(91, 72);
            this.cmb_Expense.Name = "cmb_Expense";
            this.cmb_Expense.Size = new System.Drawing.Size(121, 23);
            this.cmb_Expense.TabIndex = 6;
            // 
            // lbl_Expense
            // 
            this.lbl_Expense.AutoSize = true;
            this.lbl_Expense.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_Expense.Location = new System.Drawing.Point(6, 72);
            this.lbl_Expense.Name = "lbl_Expense";
            this.lbl_Expense.Size = new System.Drawing.Size(52, 15);
            this.lbl_Expense.TabIndex = 5;
            this.lbl_Expense.Text = "费别：";
            // 
            // txb_ID
            // 
            this.txb_ID.Location = new System.Drawing.Point(292, 41);
            this.txb_ID.Name = "txb_ID";
            this.txb_ID.Size = new System.Drawing.Size(100, 25);
            this.txb_ID.TabIndex = 4;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbl_ID.Location = new System.Drawing.Point(214, 43);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(82, 15);
            this.lbl_ID.TabIndex = 3;
            this.lbl_ID.Text = "身份证号：";
            // 
            // txb_RecordNo
            // 
            this.txb_RecordNo.Location = new System.Drawing.Point(91, 40);
            this.txb_RecordNo.Name = "txb_RecordNo";
            this.txb_RecordNo.Size = new System.Drawing.Size(100, 25);
            this.txb_RecordNo.TabIndex = 2;
            this.txb_RecordNo.TextChanged += new System.EventHandler(this.txb_RecordNo_TextChanged);
            // 
            // lbl_RecordNo
            // 
            this.lbl_RecordNo.AutoSize = true;
            this.lbl_RecordNo.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lbl_RecordNo.Location = new System.Drawing.Point(3, 43);
            this.lbl_RecordNo.Name = "lbl_RecordNo";
            this.lbl_RecordNo.Size = new System.Drawing.Size(97, 15);
            this.lbl_RecordNo.TabIndex = 1;
            this.lbl_RecordNo.Text = "住院病历号：";
            // 
            // lbl_Input
            // 
            this.lbl_Input.AutoSize = true;
            this.lbl_Input.Location = new System.Drawing.Point(214, 13);
            this.lbl_Input.Name = "lbl_Input";
            this.lbl_Input.Size = new System.Drawing.Size(97, 15);
            this.lbl_Input.TabIndex = 0;
            this.lbl_Input.Text = "病人入院录入";
            // 
            // gb_Other
            // 
            this.gb_Other.Controls.Add(this.lb_Other);
            this.gb_Other.Location = new System.Drawing.Point(692, 361);
            this.gb_Other.Name = "gb_Other";
            this.gb_Other.Size = new System.Drawing.Size(150, 100);
            this.gb_Other.TabIndex = 8;
            this.gb_Other.TabStop = false;
            this.gb_Other.Text = "其他";
            // 
            // lb_Other
            // 
            this.lb_Other.FormattingEnabled = true;
            this.lb_Other.ItemHeight = 15;
            this.lb_Other.Items.AddRange(new object[] {
            "系统维护",
            "帮助"});
            this.lb_Other.Location = new System.Drawing.Point(20, 24);
            this.lb_Other.Name = "lb_Other";
            this.lb_Other.Size = new System.Drawing.Size(120, 64);
            this.lb_Other.TabIndex = 0;
            // 
            // gb_Dictionary
            // 
            this.gb_Dictionary.Controls.Add(this.lb_Dictionary);
            this.gb_Dictionary.Location = new System.Drawing.Point(692, 241);
            this.gb_Dictionary.Name = "gb_Dictionary";
            this.gb_Dictionary.Size = new System.Drawing.Size(150, 114);
            this.gb_Dictionary.TabIndex = 7;
            this.gb_Dictionary.TabStop = false;
            this.gb_Dictionary.Text = "字典维护";
            // 
            // lb_Dictionary
            // 
            this.lb_Dictionary.FormattingEnabled = true;
            this.lb_Dictionary.ItemHeight = 15;
            this.lb_Dictionary.Items.AddRange(new object[] {
            "科室病区字典",
            "收费模板字典",
            "合同单位字典",
            "核算项目字典",
            "账单项目字典",
            "收费项目字典",
            "分科收费字典",
            "费用比例字典",
            "收费子项维护"});
            this.lb_Dictionary.Location = new System.Drawing.Point(20, 24);
            this.lb_Dictionary.Name = "lb_Dictionary";
            this.lb_Dictionary.Size = new System.Drawing.Size(120, 79);
            this.lb_Dictionary.TabIndex = 0;
            // 
            // gb_Count
            // 
            this.gb_Count.Controls.Add(this.lb_Count);
            this.gb_Count.Location = new System.Drawing.Point(692, 120);
            this.gb_Count.Name = "gb_Count";
            this.gb_Count.Size = new System.Drawing.Size(150, 110);
            this.gb_Count.TabIndex = 6;
            this.gb_Count.TabStop = false;
            this.gb_Count.Text = "统计报表";
            // 
            // lb_Count
            // 
            this.lb_Count.FormattingEnabled = true;
            this.lb_Count.ItemHeight = 15;
            this.lb_Count.Items.AddRange(new object[] {
            "应收日报表",
            "实收日报表",
            "报表生成器",
            "核算报表",
            "入出转病人报表",
            "催欠报表"});
            this.lb_Count.Location = new System.Drawing.Point(7, 24);
            this.lb_Count.Name = "lb_Count";
            this.lb_Count.Size = new System.Drawing.Size(137, 79);
            this.lb_Count.TabIndex = 0;
            // 
            // gb_Comprehensive
            // 
            this.gb_Comprehensive.Controls.Add(this.lb_Comprehensive);
            this.gb_Comprehensive.Location = new System.Drawing.Point(692, 24);
            this.gb_Comprehensive.Name = "gb_Comprehensive";
            this.gb_Comprehensive.Size = new System.Drawing.Size(150, 84);
            this.gb_Comprehensive.TabIndex = 5;
            this.gb_Comprehensive.TabStop = false;
            this.gb_Comprehensive.Text = "综合管理";
            // 
            // lb_Comprehensive
            // 
            this.lb_Comprehensive.FormattingEnabled = true;
            this.lb_Comprehensive.ItemHeight = 15;
            this.lb_Comprehensive.Items.AddRange(new object[] {
            "病人查询",
            "查询生成器",
            "新查询"});
            this.lb_Comprehensive.Location = new System.Drawing.Point(27, 24);
            this.lb_Comprehensive.Name = "lb_Comprehensive";
            this.lb_Comprehensive.Size = new System.Drawing.Size(106, 49);
            this.lb_Comprehensive.TabIndex = 0;
            // 
            // gb_Cashier
            // 
            this.gb_Cashier.Controls.Add(this.lb_Cashier);
            this.gb_Cashier.Location = new System.Drawing.Point(6, 335);
            this.gb_Cashier.Name = "gb_Cashier";
            this.gb_Cashier.Size = new System.Drawing.Size(119, 116);
            this.gb_Cashier.TabIndex = 4;
            this.gb_Cashier.TabStop = false;
            this.gb_Cashier.Text = "出纳管理";
            // 
            // lb_Cashier
            // 
            this.lb_Cashier.FormattingEnabled = true;
            this.lb_Cashier.ItemHeight = 15;
            this.lb_Cashier.Items.AddRange(new object[] {
            "单项收费",
            "确认收费",
            "退费重算",
            "收予交金",
            "坏账处理",
            "医保出纳录入"});
            this.lb_Cashier.Location = new System.Drawing.Point(8, 24);
            this.lb_Cashier.Name = "lb_Cashier";
            this.lb_Cashier.Size = new System.Drawing.Size(99, 79);
            this.lb_Cashier.TabIndex = 0;
            // 
            // gb_Fee
            // 
            this.gb_Fee.Controls.Add(this.lb_Fee);
            this.gb_Fee.Location = new System.Drawing.Point(6, 217);
            this.gb_Fee.Name = "gb_Fee";
            this.gb_Fee.Size = new System.Drawing.Size(119, 112);
            this.gb_Fee.TabIndex = 3;
            this.gb_Fee.TabStop = false;
            this.gb_Fee.Text = "费用管理";
            // 
            // lb_Fee
            // 
            this.lb_Fee.FormattingEnabled = true;
            this.lb_Fee.ItemHeight = 15;
            this.lb_Fee.Items.AddRange(new object[] {
            "医嘱计价",
            "费用录入",
            "结算处理",
            "医嘱核查",
            "医保病人结算"});
            this.lb_Fee.Location = new System.Drawing.Point(8, 24);
            this.lb_Fee.Name = "lb_Fee";
            this.lb_Fee.Size = new System.Drawing.Size(99, 79);
            this.lb_Fee.TabIndex = 0;
            // 
            // gb_Patient
            // 
            this.gb_Patient.Controls.Add(this.lb_Patient);
            this.gb_Patient.Location = new System.Drawing.Point(6, 96);
            this.gb_Patient.Name = "gb_Patient";
            this.gb_Patient.Size = new System.Drawing.Size(119, 115);
            this.gb_Patient.TabIndex = 2;
            this.gb_Patient.TabStop = false;
            this.gb_Patient.Text = "病人管理";
            // 
            // lb_Patient
            // 
            this.lb_Patient.FormattingEnabled = true;
            this.lb_Patient.ItemHeight = 15;
            this.lb_Patient.Items.AddRange(new object[] {
            "转科处理",
            "转科修改",
            "整理床位",
            "占床处理",
            "出院处理",
            "召回处理",
            "病人主索引修改",
            "转科确认"});
            this.lb_Patient.Location = new System.Drawing.Point(6, 24);
            this.lb_Patient.Name = "lb_Patient";
            this.lb_Patient.Size = new System.Drawing.Size(101, 79);
            this.lb_Patient.TabIndex = 0;
            // 
            // gb_Appointment
            // 
            this.gb_Appointment.Controls.Add(this.lb_Appointment);
            this.gb_Appointment.Location = new System.Drawing.Point(6, 24);
            this.gb_Appointment.Name = "gb_Appointment";
            this.gb_Appointment.Size = new System.Drawing.Size(107, 66);
            this.gb_Appointment.TabIndex = 0;
            this.gb_Appointment.TabStop = false;
            this.gb_Appointment.Text = "预约管理";
            // 
            // lb_Appointment
            // 
            this.lb_Appointment.FormattingEnabled = true;
            this.lb_Appointment.ItemHeight = 15;
            this.lb_Appointment.Items.AddRange(new object[] {
            "预约录入",
            "预约查询"});
            this.lb_Appointment.Location = new System.Drawing.Point(0, 24);
            this.lb_Appointment.Name = "lb_Appointment";
            this.lb_Appointment.Size = new System.Drawing.Size(79, 34);
            this.lb_Appointment.TabIndex = 0;
            this.lb_Appointment.SelectedIndexChanged += new System.EventHandler(this.lb_Appointment_SelectedIndexChanged);
            // 
            // tp_System
            // 
            this.tp_System.Controls.Add(this.pl_Initialization);
            this.tp_System.Controls.Add(this.lb_System);
            this.tp_System.Controls.Add(this.gb_System);
            this.tp_System.Location = new System.Drawing.Point(4, 25);
            this.tp_System.Name = "tp_System";
            this.tp_System.Padding = new System.Windows.Forms.Padding(3);
            this.tp_System.Size = new System.Drawing.Size(888, 513);
            this.tp_System.TabIndex = 2;
            this.tp_System.Text = "系统初始化";
            this.tp_System.UseVisualStyleBackColor = true;
            // 
            // pl_Initialization
            // 
            this.pl_Initialization.Controls.Add(this.btn_Close);
            this.pl_Initialization.Controls.Add(this.btn_Abandon);
            this.pl_Initialization.Controls.Add(this.btn_Keep);
            this.pl_Initialization.Controls.Add(this.gb_Sign);
            this.pl_Initialization.Controls.Add(this.gb_Bedfee);
            this.pl_Initialization.Controls.Add(this.gb_Number);
            this.pl_Initialization.Location = new System.Drawing.Point(187, 17);
            this.pl_Initialization.Name = "pl_Initialization";
            this.pl_Initialization.Size = new System.Drawing.Size(663, 457);
            this.pl_Initialization.TabIndex = 1;
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(573, 416);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 23);
            this.btn_Close.TabIndex = 5;
            this.btn_Close.Text = "关闭";
            this.btn_Close.UseVisualStyleBackColor = true;
            // 
            // btn_Abandon
            // 
            this.btn_Abandon.Location = new System.Drawing.Point(470, 416);
            this.btn_Abandon.Name = "btn_Abandon";
            this.btn_Abandon.Size = new System.Drawing.Size(75, 23);
            this.btn_Abandon.TabIndex = 4;
            this.btn_Abandon.Text = "放弃";
            this.btn_Abandon.UseVisualStyleBackColor = true;
            // 
            // btn_Keep
            // 
            this.btn_Keep.Location = new System.Drawing.Point(370, 416);
            this.btn_Keep.Name = "btn_Keep";
            this.btn_Keep.Size = new System.Drawing.Size(75, 23);
            this.btn_Keep.TabIndex = 3;
            this.btn_Keep.Text = "保存";
            this.btn_Keep.UseVisualStyleBackColor = true;
            // 
            // gb_Sign
            // 
            this.gb_Sign.Controls.Add(this.btn_Share);
            this.gb_Sign.Controls.Add(this.btn_Sum);
            this.gb_Sign.Controls.Add(this.btn_Total);
            this.gb_Sign.Controls.Add(this.btn_Ratio);
            this.gb_Sign.Controls.Add(this.btn_Subsection);
            this.gb_Sign.Controls.Add(this.lbl_Algorithm2);
            this.gb_Sign.Controls.Add(this.lbl_Algorithm1);
            this.gb_Sign.Controls.Add(this.lbl_Share);
            this.gb_Sign.Controls.Add(this.cb_Share);
            this.gb_Sign.Controls.Add(this.cb_Fee);
            this.gb_Sign.Location = new System.Drawing.Point(361, 232);
            this.gb_Sign.Name = "gb_Sign";
            this.gb_Sign.Size = new System.Drawing.Size(287, 157);
            this.gb_Sign.TabIndex = 2;
            this.gb_Sign.TabStop = false;
            this.gb_Sign.Text = "费用计算标志";
            // 
            // btn_Share
            // 
            this.btn_Share.Location = new System.Drawing.Point(227, 96);
            this.btn_Share.Name = "btn_Share";
            this.btn_Share.Size = new System.Drawing.Size(54, 47);
            this.btn_Share.TabIndex = 9;
            this.btn_Share.Text = "不分摊";
            this.btn_Share.UseVisualStyleBackColor = true;
            // 
            // btn_Sum
            // 
            this.btn_Sum.Location = new System.Drawing.Point(145, 120);
            this.btn_Sum.Name = "btn_Sum";
            this.btn_Sum.Size = new System.Drawing.Size(67, 23);
            this.btn_Sum.TabIndex = 8;
            this.btn_Sum.Text = "金额";
            this.btn_Sum.UseVisualStyleBackColor = true;
            // 
            // btn_Total
            // 
            this.btn_Total.Location = new System.Drawing.Point(145, 96);
            this.btn_Total.Name = "btn_Total";
            this.btn_Total.Size = new System.Drawing.Size(67, 23);
            this.btn_Total.TabIndex = 7;
            this.btn_Total.Text = "总额";
            this.btn_Total.UseVisualStyleBackColor = true;
            // 
            // btn_Ratio
            // 
            this.btn_Ratio.Location = new System.Drawing.Point(79, 120);
            this.btn_Ratio.Name = "btn_Ratio";
            this.btn_Ratio.Size = new System.Drawing.Size(62, 23);
            this.btn_Ratio.TabIndex = 6;
            this.btn_Ratio.Text = "比例";
            this.btn_Ratio.UseVisualStyleBackColor = true;
            this.btn_Ratio.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_Subsection
            // 
            this.btn_Subsection.Location = new System.Drawing.Point(79, 96);
            this.btn_Subsection.Name = "btn_Subsection";
            this.btn_Subsection.Size = new System.Drawing.Size(62, 23);
            this.btn_Subsection.TabIndex = 5;
            this.btn_Subsection.Text = "分段";
            this.btn_Subsection.UseVisualStyleBackColor = true;
            // 
            // lbl_Algorithm2
            // 
            this.lbl_Algorithm2.AutoSize = true;
            this.lbl_Algorithm2.Location = new System.Drawing.Point(6, 124);
            this.lbl_Algorithm2.Name = "lbl_Algorithm2";
            this.lbl_Algorithm2.Size = new System.Drawing.Size(67, 15);
            this.lbl_Algorithm2.TabIndex = 4;
            this.lbl_Algorithm2.Text = "算法二：";
            // 
            // lbl_Algorithm1
            // 
            this.lbl_Algorithm1.AutoSize = true;
            this.lbl_Algorithm1.Location = new System.Drawing.Point(6, 96);
            this.lbl_Algorithm1.Name = "lbl_Algorithm1";
            this.lbl_Algorithm1.Size = new System.Drawing.Size(67, 15);
            this.lbl_Algorithm1.TabIndex = 3;
            this.lbl_Algorithm1.Text = "算法一：";
            // 
            // lbl_Share
            // 
            this.lbl_Share.AutoSize = true;
            this.lbl_Share.Location = new System.Drawing.Point(12, 60);
            this.lbl_Share.Name = "lbl_Share";
            this.lbl_Share.Size = new System.Drawing.Size(97, 15);
            this.lbl_Share.TabIndex = 2;
            this.lbl_Share.Text = "总额分摊标志";
            this.lbl_Share.Click += new System.EventHandler(this.lbl_Share_Click);
            // 
            // cb_Share
            // 
            this.cb_Share.AutoSize = true;
            this.cb_Share.Location = new System.Drawing.Point(147, 38);
            this.cb_Share.Name = "cb_Share";
            this.cb_Share.Size = new System.Drawing.Size(119, 19);
            this.cb_Share.TabIndex = 1;
            this.cb_Share.Text = "账单分摊标志";
            this.cb_Share.UseVisualStyleBackColor = true;
            // 
            // cb_Fee
            // 
            this.cb_Fee.AutoSize = true;
            this.cb_Fee.Location = new System.Drawing.Point(9, 38);
            this.cb_Fee.Name = "cb_Fee";
            this.cb_Fee.Size = new System.Drawing.Size(119, 19);
            this.cb_Fee.TabIndex = 0;
            this.cb_Fee.Text = "加收费用标志";
            this.cb_Fee.UseVisualStyleBackColor = true;
            // 
            // gb_Bedfee
            // 
            this.gb_Bedfee.Controls.Add(this.gb_Calculation);
            this.gb_Bedfee.Controls.Add(this.lbl_Hint);
            this.gb_Bedfee.Controls.Add(this.txb_Bedfee);
            this.gb_Bedfee.Controls.Add(this.lbl_Bedfee);
            this.gb_Bedfee.Location = new System.Drawing.Point(361, 18);
            this.gb_Bedfee.Name = "gb_Bedfee";
            this.gb_Bedfee.Size = new System.Drawing.Size(287, 198);
            this.gb_Bedfee.TabIndex = 1;
            this.gb_Bedfee.TabStop = false;
            this.gb_Bedfee.Text = "床位费相关设置";
            // 
            // gb_Calculation
            // 
            this.gb_Calculation.Controls.Add(this.rdb_End);
            this.gb_Calculation.Controls.Add(this.rdb_First);
            this.gb_Calculation.Location = new System.Drawing.Point(29, 108);
            this.gb_Calculation.Name = "gb_Calculation";
            this.gb_Calculation.Size = new System.Drawing.Size(252, 76);
            this.gb_Calculation.TabIndex = 3;
            this.gb_Calculation.TabStop = false;
            this.gb_Calculation.Text = "床位费计算方式";
            // 
            // rdb_End
            // 
            this.rdb_End.AutoSize = true;
            this.rdb_End.Location = new System.Drawing.Point(118, 35);
            this.rdb_End.Name = "rdb_End";
            this.rdb_End.Size = new System.Drawing.Size(73, 19);
            this.rdb_End.TabIndex = 1;
            this.rdb_End.TabStop = true;
            this.rdb_End.Text = "算末天";
            this.rdb_End.UseVisualStyleBackColor = true;
            // 
            // rdb_First
            // 
            this.rdb_First.AutoSize = true;
            this.rdb_First.Location = new System.Drawing.Point(7, 35);
            this.rdb_First.Name = "rdb_First";
            this.rdb_First.Size = new System.Drawing.Size(73, 19);
            this.rdb_First.TabIndex = 0;
            this.rdb_First.TabStop = true;
            this.rdb_First.Text = "算头天";
            this.rdb_First.UseVisualStyleBackColor = true;
            // 
            // lbl_Hint
            // 
            this.lbl_Hint.AutoSize = true;
            this.lbl_Hint.Location = new System.Drawing.Point(6, 72);
            this.lbl_Hint.Name = "lbl_Hint";
            this.lbl_Hint.Size = new System.Drawing.Size(247, 30);
            this.lbl_Hint.TabIndex = 2;
            this.lbl_Hint.Text = "在后台程序产生床位费费用记录时，\r\n填入的操作员。";
            // 
            // txb_Bedfee
            // 
            this.txb_Bedfee.Location = new System.Drawing.Point(159, 34);
            this.txb_Bedfee.Name = "txb_Bedfee";
            this.txb_Bedfee.Size = new System.Drawing.Size(100, 25);
            this.txb_Bedfee.TabIndex = 1;
            // 
            // lbl_Bedfee
            // 
            this.lbl_Bedfee.AutoSize = true;
            this.lbl_Bedfee.Location = new System.Drawing.Point(6, 37);
            this.lbl_Bedfee.Name = "lbl_Bedfee";
            this.lbl_Bedfee.Size = new System.Drawing.Size(142, 15);
            this.lbl_Bedfee.TabIndex = 0;
            this.lbl_Bedfee.Text = "床位费产生操作员：";
            // 
            // gb_Number
            // 
            this.gb_Number.Controls.Add(this.gb_Switch);
            this.gb_Number.Controls.Add(this.txb_Medical);
            this.gb_Number.Controls.Add(this.txb_Charge);
            this.gb_Number.Controls.Add(this.txb_Appointment);
            this.gb_Number.Controls.Add(this.txb_Receipt);
            this.gb_Number.Controls.Add(this.lbl_Medical);
            this.gb_Number.Controls.Add(this.lbl_Charge);
            this.gb_Number.Controls.Add(this.lbl_Appointment);
            this.gb_Number.Controls.Add(this.lbl_Receipt);
            this.gb_Number.Location = new System.Drawing.Point(36, 18);
            this.gb_Number.Name = "gb_Number";
            this.gb_Number.Size = new System.Drawing.Size(295, 275);
            this.gb_Number.TabIndex = 0;
            this.gb_Number.TabStop = false;
            this.gb_Number.Text = "序号类设置";
            // 
            // gb_Switch
            // 
            this.gb_Switch.Controls.Add(this.rdb_Automatic);
            this.gb_Switch.Controls.Add(this.rdb_Manual);
            this.gb_Switch.Location = new System.Drawing.Point(6, 187);
            this.gb_Switch.Name = "gb_Switch";
            this.gb_Switch.Size = new System.Drawing.Size(283, 65);
            this.gb_Switch.TabIndex = 8;
            this.gb_Switch.TabStop = false;
            this.gb_Switch.Text = "病历号自动产生开关";
            // 
            // rdb_Automatic
            // 
            this.rdb_Automatic.AutoSize = true;
            this.rdb_Automatic.Location = new System.Drawing.Point(172, 25);
            this.rdb_Automatic.Name = "rdb_Automatic";
            this.rdb_Automatic.Size = new System.Drawing.Size(88, 19);
            this.rdb_Automatic.TabIndex = 1;
            this.rdb_Automatic.TabStop = true;
            this.rdb_Automatic.Text = "自动产生";
            this.rdb_Automatic.UseVisualStyleBackColor = true;
            // 
            // rdb_Manual
            // 
            this.rdb_Manual.AutoSize = true;
            this.rdb_Manual.Location = new System.Drawing.Point(6, 24);
            this.rdb_Manual.Name = "rdb_Manual";
            this.rdb_Manual.Size = new System.Drawing.Size(88, 19);
            this.rdb_Manual.TabIndex = 0;
            this.rdb_Manual.TabStop = true;
            this.rdb_Manual.Text = "手动产生";
            this.rdb_Manual.UseVisualStyleBackColor = true;
            // 
            // txb_Medical
            // 
            this.txb_Medical.Location = new System.Drawing.Point(148, 145);
            this.txb_Medical.Name = "txb_Medical";
            this.txb_Medical.Size = new System.Drawing.Size(100, 25);
            this.txb_Medical.TabIndex = 7;
            // 
            // txb_Charge
            // 
            this.txb_Charge.Location = new System.Drawing.Point(148, 103);
            this.txb_Charge.Name = "txb_Charge";
            this.txb_Charge.Size = new System.Drawing.Size(100, 25);
            this.txb_Charge.TabIndex = 6;
            // 
            // txb_Appointment
            // 
            this.txb_Appointment.Location = new System.Drawing.Point(148, 62);
            this.txb_Appointment.Name = "txb_Appointment";
            this.txb_Appointment.Size = new System.Drawing.Size(100, 25);
            this.txb_Appointment.TabIndex = 5;
            // 
            // txb_Receipt
            // 
            this.txb_Receipt.Location = new System.Drawing.Point(148, 25);
            this.txb_Receipt.Name = "txb_Receipt";
            this.txb_Receipt.Size = new System.Drawing.Size(100, 25);
            this.txb_Receipt.TabIndex = 4;
            // 
            // lbl_Medical
            // 
            this.lbl_Medical.AutoSize = true;
            this.lbl_Medical.Location = new System.Drawing.Point(44, 148);
            this.lbl_Medical.Name = "lbl_Medical";
            this.lbl_Medical.Size = new System.Drawing.Size(97, 15);
            this.lbl_Medical.TabIndex = 3;
            this.lbl_Medical.Text = "病历号序号：";
            // 
            // lbl_Charge
            // 
            this.lbl_Charge.AutoSize = true;
            this.lbl_Charge.Location = new System.Drawing.Point(0, 106);
            this.lbl_Charge.Name = "lbl_Charge";
            this.lbl_Charge.Size = new System.Drawing.Size(142, 15);
            this.lbl_Charge.TabIndex = 2;
            this.lbl_Charge.Text = "收费项目编码序号：";
            // 
            // lbl_Appointment
            // 
            this.lbl_Appointment.AutoSize = true;
            this.lbl_Appointment.Location = new System.Drawing.Point(59, 65);
            this.lbl_Appointment.Name = "lbl_Appointment";
            this.lbl_Appointment.Size = new System.Drawing.Size(82, 15);
            this.lbl_Appointment.TabIndex = 1;
            this.lbl_Appointment.Text = "预约序号：";
            // 
            // lbl_Receipt
            // 
            this.lbl_Receipt.AutoSize = true;
            this.lbl_Receipt.Location = new System.Drawing.Point(59, 28);
            this.lbl_Receipt.Name = "lbl_Receipt";
            this.lbl_Receipt.Size = new System.Drawing.Size(82, 15);
            this.lbl_Receipt.TabIndex = 0;
            this.lbl_Receipt.Text = "收据序号：";
            // 
            // lb_System
            // 
            this.lb_System.FormattingEnabled = true;
            this.lb_System.ItemHeight = 15;
            this.lb_System.Items.AddRange(new object[] {
            "系统运行参数初始化",
            "病人入院交费设置",
            "系统变量初始化"});
            this.lb_System.Location = new System.Drawing.Point(17, 54);
            this.lb_System.Name = "lb_System";
            this.lb_System.Size = new System.Drawing.Size(151, 94);
            this.lb_System.TabIndex = 0;
            // 
            // gb_System
            // 
            this.gb_System.Location = new System.Drawing.Point(6, 6);
            this.gb_System.Name = "gb_System";
            this.gb_System.Size = new System.Drawing.Size(864, 485);
            this.gb_System.TabIndex = 2;
            this.gb_System.TabStop = false;
            this.gb_System.Text = "系统初始化";
            // 
            // tp_management
            // 
            this.tp_management.Location = new System.Drawing.Point(4, 25);
            this.tp_management.Name = "tp_management";
            this.tp_management.Padding = new System.Windows.Forms.Padding(3);
            this.tp_management.Size = new System.Drawing.Size(888, 513);
            this.tp_management.TabIndex = 3;
            this.tp_management.Text = "用户管理";
            this.tp_management.UseVisualStyleBackColor = true;
            // 
            // frm_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 582);
            this.Controls.Add(this.tc_System);
            this.Name = "frm_Page";
            this.Text = "住院子系统";
            this.Load += new System.EventHandler(this.frm_Page_Load);
            this.tc_System.ResumeLayout(false);
            this.tp_Window.ResumeLayout(false);
            this.gb_Window.ResumeLayout(false);
            this.pl_Input.ResumeLayout(false);
            this.pl_Input.PerformLayout();
            this.pl_AppoEnquiry.ResumeLayout(false);
            this.gb_Other.ResumeLayout(false);
            this.gb_Dictionary.ResumeLayout(false);
            this.gb_Count.ResumeLayout(false);
            this.gb_Comprehensive.ResumeLayout(false);
            this.gb_Cashier.ResumeLayout(false);
            this.gb_Fee.ResumeLayout(false);
            this.gb_Patient.ResumeLayout(false);
            this.gb_Appointment.ResumeLayout(false);
            this.tp_System.ResumeLayout(false);
            this.pl_Initialization.ResumeLayout(false);
            this.gb_Sign.ResumeLayout(false);
            this.gb_Sign.PerformLayout();
            this.gb_Bedfee.ResumeLayout(false);
            this.gb_Bedfee.PerformLayout();
            this.gb_Calculation.ResumeLayout(false);
            this.gb_Calculation.PerformLayout();
            this.gb_Number.ResumeLayout(false);
            this.gb_Number.PerformLayout();
            this.gb_Switch.ResumeLayout(false);
            this.gb_Switch.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tc_System;
        private System.Windows.Forms.TabPage tp_Window;
        private System.Windows.Forms.TabPage tp_System;
        private System.Windows.Forms.TabPage tp_management;
        private System.Windows.Forms.ListBox lb_System;
        private System.Windows.Forms.Panel pl_Initialization;
        private System.Windows.Forms.GroupBox gb_Number;
        private System.Windows.Forms.Label lbl_Medical;
        private System.Windows.Forms.Label lbl_Charge;
        private System.Windows.Forms.Label lbl_Appointment;
        private System.Windows.Forms.Label lbl_Receipt;
        private System.Windows.Forms.TextBox txb_Medical;
        private System.Windows.Forms.TextBox txb_Charge;
        private System.Windows.Forms.TextBox txb_Appointment;
        private System.Windows.Forms.TextBox txb_Receipt;
        private System.Windows.Forms.GroupBox gb_Sign;
        private System.Windows.Forms.Label lbl_Share;
        private System.Windows.Forms.CheckBox cb_Share;
        private System.Windows.Forms.CheckBox cb_Fee;
        private System.Windows.Forms.GroupBox gb_Bedfee;
        private System.Windows.Forms.GroupBox gb_Calculation;
        private System.Windows.Forms.RadioButton rdb_End;
        private System.Windows.Forms.RadioButton rdb_First;
        private System.Windows.Forms.Label lbl_Hint;
        private System.Windows.Forms.TextBox txb_Bedfee;
        private System.Windows.Forms.Label lbl_Bedfee;
        private System.Windows.Forms.GroupBox gb_Switch;
        private System.Windows.Forms.RadioButton rdb_Automatic;
        private System.Windows.Forms.RadioButton rdb_Manual;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Button btn_Abandon;
        private System.Windows.Forms.Button btn_Keep;
        private System.Windows.Forms.Label lbl_Algorithm2;
        private System.Windows.Forms.Label lbl_Algorithm1;
        private System.Windows.Forms.Button btn_Ratio;
        private System.Windows.Forms.Button btn_Subsection;
        private System.Windows.Forms.Button btn_Share;
        private System.Windows.Forms.Button btn_Sum;
        private System.Windows.Forms.Button btn_Total;
        private System.Windows.Forms.GroupBox gb_Window;
        private System.Windows.Forms.GroupBox gb_Cashier;
        private System.Windows.Forms.ListBox lb_Cashier;
        private System.Windows.Forms.GroupBox gb_Fee;
        private System.Windows.Forms.ListBox lb_Fee;
        private System.Windows.Forms.GroupBox gb_Patient;
        private System.Windows.Forms.ListBox lb_Patient;
        private System.Windows.Forms.GroupBox gb_Appointment;
        private System.Windows.Forms.ListBox lb_Appointment;
        private System.Windows.Forms.GroupBox gb_System;
        private System.Windows.Forms.GroupBox gb_Other;
        private System.Windows.Forms.GroupBox gb_Dictionary;
        private System.Windows.Forms.ListBox lb_Dictionary;
        private System.Windows.Forms.GroupBox gb_Count;
        private System.Windows.Forms.ListBox lb_Count;
        private System.Windows.Forms.GroupBox gb_Comprehensive;
        private System.Windows.Forms.ListBox lb_Comprehensive;
        private System.Windows.Forms.ListBox lb_Other;
        private System.Windows.Forms.Panel pl_Input;
        private System.Windows.Forms.RadioButton rdb_Female;
        private System.Windows.Forms.RadioButton rdb_Male;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.TextBox txb_Name;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.DateTimePicker dtp_AdmissionDate;
        private System.Windows.Forms.Label lbl_AdmissionDate;
        private System.Windows.Forms.ComboBox cmb_Expense;
        private System.Windows.Forms.Label lbl_Expense;
        private System.Windows.Forms.TextBox txb_ID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox txb_RecordNo;
        private System.Windows.Forms.Label lbl_RecordNo;
        private System.Windows.Forms.Label lbl_Input;
        private System.Windows.Forms.ComboBox cmb_Department;
        private System.Windows.Forms.Label lbl_Department;
        private System.Windows.Forms.Label lbl_Hospitalization;
        private System.Windows.Forms.TextBox txb_Diagnosis;
        private System.Windows.Forms.Label lbl_Diagnosis;
        private System.Windows.Forms.TextBox txb_Address;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.TextBox txb_Marital;
        private System.Windows.Forms.Label lbl_Marital;
        private System.Windows.Forms.TextBox txb_Nation;
        private System.Windows.Forms.Label lbl_Nation;
        private System.Windows.Forms.TextBox txb_MeCertificateNo;
        private System.Windows.Forms.Label lbl_MeCertificateNo;
        private System.Windows.Forms.TextBox txb_OutpatientNo;
        private System.Windows.Forms.Label lbl_OutpatientNo;
        private System.Windows.Forms.TextBox txb_ReservationNo;
        private System.Windows.Forms.Label lbl_ReservationNo;
        private System.Windows.Forms.Button btn_Load;
        private System.Windows.Forms.TextBox txb_Hospitalization;
        private System.Windows.Forms.Panel pl_AppoEnquiry;
        private System.Windows.Forms.Button btn_AppoEnquiry;
    }
}