﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HosBase
{
    public partial class frm_Register : Form
    {
        public frm_Register()
        {
            InitializeComponent();
        }

        private void btn_SignUp_Click(object sender, EventArgs e)
        {
            if (this.txb_UserNo.Text.Trim() == "")
            {
                MessageBox.Show("用户号不能为空！");
                this.txb_UserNo.Focus();
                return;
            }
            if (this.txb_Password.Text.Trim() == "")
            {
                MessageBox.Show("密码不能为空！");
                this.txb_Password.Focus();
                return;
            }
            if (this.txb_UserNo.Text.Trim().Length != 10)
            {
                MessageBox.Show("账号长度必须为10位！");
                this.txb_UserNo.Focus();
                return;
            }
            SqlConnection sqlConnection = new SqlConnection();                                         
            sqlConnection.ConnectionString =
                "Server=(local);Database=HosBase;Integrated Security=sspi";                        
            SqlCommand sqlCommand = sqlConnection.CreateCommand();                                    
            sqlCommand.CommandText =
                "INSERT tb_User (UserNo,Password) VALUES(@UserNo,HASHBYTES('MD5',@Password));";                 //指定SQL命令的命令文本；命令文本包含参数；
            sqlCommand.Parameters.AddWithValue("@UserNo", this.txb_UserNo.Text.Trim());                     //向SQL命令的参数集合添加参数的名称、值；
            sqlCommand.Parameters.AddWithValue("@Password", this.txb_Password.Text.Trim());
            sqlCommand.Parameters["@Password"].SqlDbType = SqlDbType.VarChar;                           //将密码参数的类型设为变长字符串；
                                                                                                        //SQL参数自动识别类型；若参数值为字符串，则类型自动设为NVARCHAR，且可在执行时自动转换；但对于相同密码，VARCHAR/NVARCHAR类型所获得的散列值不同，故需手动将SQL参数类型统一设为VARCHAR;
            sqlConnection.Open();                                                                       //打开SQL连接；
            int rowAffected = sqlCommand.ExecuteNonQuery();                                             //调用SQL命令的方法ExecuteNonQuery来执行命令，向数据库写入数据，并返回受影响行数；
            sqlConnection.Close();                                                                      //关闭SQL连接；
            if (rowAffected == 1)                                                                       //若成功写入1行记录；
            {
                MessageBox.Show("注册成功。");
                frm_Login frm_Login = new frm_Login();
                frm_Login.Show();
            }
            else                                                                                        //否则；
            {
                MessageBox.Show("注册失败！");															//给出错误提示；
            }
        }

    }
}

