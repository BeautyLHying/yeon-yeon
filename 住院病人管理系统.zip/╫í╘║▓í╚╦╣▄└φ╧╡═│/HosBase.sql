USE HosBase;
IF OBJECT_ID ('tb_User') IS NOT NULL
DROP TABLE tb_User 
CREATE TABLE tb_User
(UserNo
CHAR(10)
NOT NULL
CONSTRAINT pk_User_No
PRIMARY KEY(UserNo)
CONSTRAINT ck_User_No
CHECK(UserNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
,Password
VARCHAR(50)
NOT NULL
,Name
VARCHAR(50));
INSERT tb_User
(UserNo
,Password
,Name)
VALUES('3200707018',HASHBYTES('MD5','3200707018'),'����ӯ')
SELECT L.UserNo
,L.Password
,L.Name
FROM tb_User AS L
WHERE L.UserNo='3200707018';
UPDATE tb_User
SET Password=HASHBYTES('MD5','3200707018')
 WHERE UserNo='3200707018';

 
  IF OBJECT_ID ('tb_Patient') IS NOT NULL
DROP TABLE tb_Patient 

 CREATE TABLE tb_Patient
 (No
 CHAR(5)
 NOT NULL

PRIMARY KEY
 ,ID
 CHAR(18)
 NOT NULL
 CHECK(ID LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
 ,ExpenseNo
VARCHAR(10)
NOT NULL
 ,AdmissionDate
 DATE
 NOT NULL
 ,Name
 VARCHAR(20)
 NOT NULL
 ,Gender
 BIT 
 NOT NULL
 ,Hospitalization
 VARCHAR(3)
 NOT NULL
 ,DepartmentNo
 VARCHAR(20)
 NOT NULL
 ,ReservationNo
 VARCHAR(10)
 NULL
 ,OutpatientNo
 VARCHAR(10)
 NULL
 ,MeCertificateNo
 VARCHAR(10)
 NULL
 ,Nation
 VARCHAR(10)
 NULL
 ,Marital
 CHAR(2)
 NULL
 ,Address
 VARCHAR(100)
 NULL
 ,Diagnosis
 VARCHAR(100)
 NULL);
 INSERT tb_Patient
 (No,ID,ExpenseNo,AdmissionDate,Name,Gender,Hospitalization,DepartmentNo,ReservationNo,OutpatientNo,MeCertificateNo,Nation,Marital,Address,Diagnosis)
  VALUES
 ('A0009','350350200009033511',' ','2022-03-01','ee',0,'1',' ','000005',' ',' ',' ',' ',' ',' ')
 
